
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","EnumAbstract"],["c","EnumUtils"],["c","Exception"],["c","InvalidArgumentException"],["c","LogicException"],["c","RuntimeException"],["c","UnexpectedValueException"]];
