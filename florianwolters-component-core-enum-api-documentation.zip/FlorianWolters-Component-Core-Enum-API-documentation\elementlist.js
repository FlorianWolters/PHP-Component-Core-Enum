
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Core\\Enum\\EnumAbstract"],["c","FlorianWolters\\Component\\Core\\Enum\\EnumUtils"]];
