
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","EnumAbstract"],["c","EnumUtils"]];
